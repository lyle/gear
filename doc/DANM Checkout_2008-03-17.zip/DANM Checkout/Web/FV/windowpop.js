//script	var IE = navigator.appVersion.indexOf("MSIE")>0;	var msieIndex = navigator.appVersion.indexOf("MSIE") + 5;	var version = parseFloat(navigator.appVersion.substr(msieIndex,3))	var IE4 = IE && version>=4 && version<5;	var IE5 = IE && version>=5;	var Macintosh = navigator.userAgent.indexOf('Mac')>0;		function preload(imgObj,imgSrc) {		if (document.images) {			eval(imgObj+' = new Image()')			eval(imgObj+'.src = "'+imgSrc+'"')		}	}			function NewWindow(desktopURL,windowName,width,height) { 		if (Macintosh) { 			if (IE4) { newheight = 17 + height; } 			else { newheight = height; } 		} 		else { newheight = height; }	 		window.open(desktopURL, windowName, "toolbar=no,location=no,status=yes,menubar=no,scrollbars=no,width="+width+",height="+newheight+",resizable=no" );	}	function ForPaul(desktopURL,windowName,width,height) {
 		if (Macintosh) {
 			if (IE4) { newheight = 17 + height; }
 			else { newheight = height; }
 		}
 		else { newheight = height; }	
 		window.open(desktopURL, windowName, "toolbar=no,location=no,status=yes,menubar=no,scrollbars=yes,width="+width+",height="+newheight+",resizable=no" );
	}
